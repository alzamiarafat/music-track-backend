'use strict';
const express = require('express');
const router = express.Router();
const controller = require('../controllers');


router.get('/musics', controller.MusicController.index);
router.post('/musics', controller.MusicController.create);

router.get('/', (req, res) => {
    console.log("🚀 ~ file: route.js:9 ~ router.get ~ res:", res)
    res.send(':)');
});

module.exports = router;
