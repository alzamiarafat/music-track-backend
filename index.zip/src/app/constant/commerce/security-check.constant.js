module.exports = Object.freeze({
    name: 'SecurityCheckConstant',

    SECURITY_CHECK_TYPE_IN     : 'in',
    SECURITY_CHECK_TYPE_OUT     : 'out',

});
