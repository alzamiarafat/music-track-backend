module.exports = Object.freeze({
    name: 'WarehouseConstant',

    WAREHOUSE_TYPE_PHYSICAL     : 'physical',
    WAREHOUSE_TYPE_VIRTUAL     : 'virtual',

    WAREHOUSE_PREFIX : 'warehouse_',
});
