module.exports = Object.freeze({
    name: 'DeliveryParcelConstant',
    
    DELIVERY_PARTNER_KX: 'KX Transport',
    DELIVERY_PARTNER_SHUNDARBAN: 'Shundarban',
    DELIVERY_PARTNER_SA: 'SA Paribahan',
});
