'use strict';
const errorMiddleware = require('./error.middleware');

module.exports = {
    errorMiddleware
};
