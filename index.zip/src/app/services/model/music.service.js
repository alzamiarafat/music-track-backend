const MusicRepository = require("../../repositories/music.repository");

const MusicService = {
    getAll: async (req) => {
        return await MusicRepository.all(req);
    },

    store: async (req) => {
        const { title, artist, url } = req.body;
        const data = { title, artist, url };

        return await MusicRepository.store(data);
    }
};

MusicService.name = 'MusicService';
module.exports = MusicService;
